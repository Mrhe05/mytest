#ifndef _DRV_SYN6288_H_
#define _DRV_SYN6288_H_

#include "stm32f10x.h"

void SYN_FrameInfo(u8 Music, u8 *HZdata);
void YS_SYN_Set(u8 *Info_data);

#endif

