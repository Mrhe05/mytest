#ifndef __DRV_USART_H__
#define __DRV_USART_H__

#include "stm32f10x.h"
#include "stdio.h"

void USART_Config(void);


#endif //__DRV_USART_H__
