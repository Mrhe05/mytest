#ifndef __DRV_ADC_H__
#define __DRV_ADC_H__


#include "stm32f10x.h"


void ADC1_Config(void);
uint16_t ADC1_RG_Value(void);
uint16_t ADC1_KEY_Value(void);

#endif //__DRV_ADC_H__
