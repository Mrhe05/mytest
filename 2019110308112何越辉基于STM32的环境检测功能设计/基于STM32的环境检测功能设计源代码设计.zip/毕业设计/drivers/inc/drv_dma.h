#ifndef __DRV_DMA_H__
#define __DRV_DMA_H__

#include "stm32f10x.h"


void DMA1_Config(uint32_t *src,uint32_t *drc,uint32_t size);
uint8_t DMA_CompareISok(uint32_t *src,uint32_t *drc,uint32_t size);


#endif //__DRV_DMA_H__
