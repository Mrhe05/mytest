#ifndef __DRV_EXTI_H__
#define __DRV_EXTI_H__

#include "stm32f10x.h"

void EXTI_Config(void);



#endif //__DRV_EXTI_H__
