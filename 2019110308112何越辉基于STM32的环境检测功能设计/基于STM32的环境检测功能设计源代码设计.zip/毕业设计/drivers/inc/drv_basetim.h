#ifndef __DRV_BASETIM_H__
#define __DRV_BASETIM_H__

#include "stm32f10x.h"

void TIM7_Config(void);


#endif //__DRV_BASETIM_H__
