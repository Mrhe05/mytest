#ifndef _OLED_APPLY_H_
#define _OLED_APPLY_H_
void TEST_MainPage(void);
void Test_Color(void);
void Test_Rectangular(void);
void Test_Circle(void);
void Test_Triangle(void);
void TEST_English(void);
void TEST_Number_Character(void);
void TEST_Chinese(void);
void TEST_Chinese1(void);
void TEST_BMP(void);
void TEST_Menu1(void);
void TEST_Menu2(void);
#endif

