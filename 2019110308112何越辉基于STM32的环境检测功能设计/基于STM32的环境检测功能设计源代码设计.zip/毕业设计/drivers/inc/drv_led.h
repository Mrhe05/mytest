#ifndef __DRV_LED_H__
#define __DRV_LED_H__

#include "stm32f10x.h"
#define      BUZ   GPIO_Pin_9
#define      LEDR   GPIO_Pin_8
#define      LEDG   GPIO_Pin_7
#define      LEDB   GPIO_Pin_6
#define      OPEN      GPIO_ResetBits  
#define      CLOSE     GPIO_SetBits 

void LED_Config(void);
void LEDR_OPEN(void);
void LEDR_CLOSE(void);
void LED_CTL(u16 LED,void(*fun)(GPIO_TypeDef*,u16));

#endif //__DRV_LED_H__
 

