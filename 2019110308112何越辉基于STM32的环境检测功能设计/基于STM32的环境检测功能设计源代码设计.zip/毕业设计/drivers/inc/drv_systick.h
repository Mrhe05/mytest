#ifndef __DRV_SYSTICK_H__
#define __DRV_SYSTICK_H__

#include "stm32f10x.h"

void SysTicks_Config(uint32_t sysclk);
void SYSTICKs_DelayNms(uint32_t Nms);
void SYSTICKs_DelayNus(uint32_t Nus);

#endif //__DRV_SYSTICK_H__
