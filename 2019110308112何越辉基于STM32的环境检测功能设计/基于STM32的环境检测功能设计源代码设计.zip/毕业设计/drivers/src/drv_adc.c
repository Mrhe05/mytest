#include "drv_adc.h"
#define ADC_CH   2
#define ADC_DATA_SIZE  50

uint16_t ADC1_DATA[ADC_DATA_SIZE][ADC_CH];
void ADC1_Config(void)
{
	GPIO_InitTypeDef  GPIO_InitStruct;
	 ADC_InitTypeDef  ADC_InitStruct;
	 DMA_InitTypeDef  DMA_InitStruct;
	// 1����ʱ��
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO|RCC_APB2Periph_ADC1|RCC_APB2Periph_GPIOC,ENABLE);

	// 2��ADCԤ��Ƶ��6��Ƶ
	RCC_ADCCLKConfig(RCC_PCLK2_Div6);

	// 3����ʼ��GPIOC
	GPIO_InitStruct.GPIO_Mode        =GPIO_Mode_AIN;
	GPIO_InitStruct.GPIO_Pin         =GPIO_Pin_0|GPIO_Pin_1;
	GPIO_Init(GPIOC,&GPIO_InitStruct);

	// 4����ʼ��ADC1
	ADC_InitStruct.ADC_ContinuousConvMode    =ENABLE; //�Ƿ�����ת��
	ADC_InitStruct.ADC_DataAlign             =ADC_DataAlign_Right; //���ݶ��뷽ʽ
	ADC_InitStruct.ADC_ExternalTrigConv      =ADC_ExternalTrigConv_None;//�Ƿ�ʹ���ⲿ����
	ADC_InitStruct.ADC_Mode                  =ADC_Mode_Independent;//adc�����ڶ���ģʽ
	ADC_InitStruct.ADC_NbrOfChannel          =ADC_CH;// ADCͨ����Ŀ
	ADC_InitStruct.ADC_ScanConvMode          =ENABLE;//�Ƿ�ʹ��ɨ��
	ADC_Init(ADC1,&ADC_InitStruct);

	// 5��ʹ��ADC��DMA
    ADC_DMACmd(ADC1,ENABLE);

	// 6����ʼ��DMA
	DMA_InitStruct.DMA_PeripheralBaseAddr   =(uint32_t)&ADC1->DR;
	DMA_InitStruct.DMA_MemoryBaseAddr       =(uint32_t)ADC1_DATA;
	DMA_InitStruct.DMA_DIR                  =DMA_DIR_PeripheralSRC;
	DMA_InitStruct.DMA_PeripheralDataSize   =DMA_PeripheralDataSize_HalfWord;
	DMA_InitStruct.DMA_MemoryDataSize       =DMA_MemoryDataSize_HalfWord;
	DMA_InitStruct.DMA_PeripheralInc        =DMA_PeripheralInc_Disable;
	DMA_InitStruct.DMA_MemoryInc            =DMA_MemoryInc_Enable;
	DMA_InitStruct.DMA_M2M                  =DMA_M2M_Disable;
	DMA_InitStruct.DMA_Mode                 =DMA_Mode_Circular;
	DMA_InitStruct.DMA_Priority             =DMA_Priority_High;
	DMA_InitStruct.DMA_BufferSize           =ADC_CH*ADC_DATA_SIZE;
	DMA_Init(DMA1_Channel1,&DMA_InitStruct);

	// 7��ʹ��dma1��ͨ��1
	DMA_Cmd(DMA1_Channel1,ENABLE);

	// 8�����ù��������˳��Ͳ���ʱ��
	ADC_RegularChannelConfig(ADC1,ADC_Channel_10,1, ADC_SampleTime_239Cycles5);
	ADC_RegularChannelConfig(ADC1,ADC_Channel_11,2, ADC_SampleTime_239Cycles5);

	// 9��ʹ��ADC 
	ADC_Cmd(ADC1,ENABLE);

	// 10��ADC��У׼
	ADC_ResetCalibration(ADC1);
	while(SET==ADC_GetResetCalibrationStatus(ADC1));//----�ο������ֲᣬ�Ĵ���(ADC_CR2)
	ADC_StartCalibration(ADC1);
	while(SET==ADC_GetCalibrationStatus(ADC1));

	// 11����������ADC
	ADC_SoftwareStartConvCmd(ADC1, ENABLE);
}

uint16_t ADC1_RG_Value(void)
{
	uint32_t SUM=0;
	uint8_t i;
	for(i=0;i<ADC_DATA_SIZE;i++){
		SUM=SUM+ADC1_DATA[i][0];
	}
	return (uint16_t)(SUM/ADC_DATA_SIZE);
}
uint16_t ADC1_KEY_Value(void)
{
	uint32_t SUM=0;
	uint8_t i;
	for(i=0;i<ADC_DATA_SIZE;i++){
		SUM=SUM+ADC1_DATA[i][1];
	}
	return (uint16_t)(SUM/ADC_DATA_SIZE);
}


