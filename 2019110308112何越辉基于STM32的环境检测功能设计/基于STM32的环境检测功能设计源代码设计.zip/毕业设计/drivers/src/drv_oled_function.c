#include "drv_oled_function.h"
#include "drv_dht11.h"
#include "drv_systick.h"
#include "drv_usart.h"
#include "stdio.h"
#include "drv_exti.h"
#include "drv_dma.h"
#include "drv_adc.h"
#include "drv_oled.h"
#include "oled_gui.h"
#include "oled_apply.h"
#include "drv_led.h"
#include "drv_basetim.h"
#include "drv_oled_function.h"
#include "drv_dht11.h"
u8 temperature=0;
u8 humidity=0;

void OLED_Init_FunctionName(void)
{
	OLED_Init();
	OLED_Clear(0);
	GUI_ShowCHinese(32,0,16,"��������",1);
	GUI_ShowCHinese(0,18,16,"����ǿ��",1);
	GUI_ShowCHinese(0,42,16,"�¶�",1);

	GUI_ShowCHinese(66,42,16,"ʪ��",1);
	GUI_ShowString(62,17,":",16,1);
	GUI_ShowString(30,41,":",16,1);
	GUI_ShowString(96,41,":",16,1);	
}

void OLED_Function(void)
{
	DHT11_Read_Data(&temperature,&humidity);
	GUI_ShowNum(68,18,ADC1_RG_Value(),4,16,1);
	GUI_ShowNum(37,42,temperature,2,16,1);
	GUI_ShowNum(105,42,humidity,2,16,1);
	if(temperature>20)
	LED_CTL(BUZ,OPEN);
	SYSTICKs_DelayNms(500);
	LED_CTL(BUZ,CLOSE);	
}

void OLED_symbol(void)
{
		GUI_Fill(0,0,30,17,1);
		GUI_Fill(96,0,125,17,1);
		GUI_Fill(0,17,125,17,1);
		GUI_Fill(0,35,125,41,1);
		GUI_Fill(0,59,125,100,1);
}

void OLED_Login_now(void)
{	
	OLED_Init();
	OLED_Clear(0);
	GUI_ShowCHinese(16,20,24,"���ڵ�¼",1);
	
}

void OLED_Login_successful(void)
{	
	OLED_Init();
	OLED_Clear(0);
	GUI_ShowCHinese(16,20,24,"��¼�ɹ�",1);
}

void OLED_Continuous(void)
{
	OLED_Display();
//	GUI_ShowString(75,42,".",16,1);
	OLED_Display();
	SYSTICKs_DelayNms(500);

//	GUI_ShowString(75,42,"..",16,1);
	OLED_Display();
	SYSTICKs_DelayNms(500);
//	GUI_ShowString(75,42,"...",16,1);
	OLED_Display();
	SYSTICKs_DelayNms(500);
//	GUI_ShowString(75,42,"....",16,1);
	OLED_Display();
	SYSTICKs_DelayNms(500);
//	GUI_ShowString(75,42,".....",16,1);
	OLED_Display();
	SYSTICKs_DelayNms(500);
	GUI_Fill(75,52,110,56,0);
}
