#include "drv_dma.h"

void DMA1_Config(uint32_t *src,uint32_t *drc,uint32_t size)
{
	DMA_InitTypeDef  DMA_InitStruct;
	NVIC_InitTypeDef  NVIC_InitStruct;
	// 1����ʱ�� 
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

	// 2����ʼ��DMA 
	DMA_InitStruct.DMA_BufferSize          =size;
	DMA_InitStruct.DMA_DIR                 =DMA_DIR_PeripheralSRC;
	DMA_InitStruct.DMA_M2M                 =DMA_M2M_Enable;
	DMA_InitStruct.DMA_MemoryBaseAddr      =(uint32_t)drc;
	DMA_InitStruct.DMA_MemoryDataSize      =DMA_MemoryDataSize_Word;
	DMA_InitStruct.DMA_MemoryInc           =DMA_MemoryInc_Enable;
	DMA_InitStruct.DMA_Mode                =DMA_Mode_Normal;
	DMA_InitStruct.DMA_PeripheralBaseAddr  =(uint32_t)src;
	DMA_InitStruct.DMA_PeripheralDataSize  =DMA_PeripheralDataSize_Word;
	DMA_InitStruct.DMA_PeripheralInc       =DMA_PeripheralInc_Enable;
	DMA_InitStruct.DMA_Priority            =DMA_Priority_VeryHigh;
	DMA_Init(DMA1_Channel7,&DMA_InitStruct);

	// �ж�Դ����
	DMA_ITConfig(DMA1_Channel7, DMA_IT_TC,ENABLE);

	// �����ж����ȼ�
	NVIC_InitStruct.NVIC_IRQChannel       =DMA1_Channel7_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority   =0;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority          =3;
	NVIC_InitStruct.NVIC_IRQChannelCmd    =ENABLE;
	NVIC_Init(&NVIC_InitStruct);
	// 3��ʹ��DMA
	DMA_Cmd(DMA1_Channel7,ENABLE);

}


uint8_t DMA_CompareISok(uint32_t *src,uint32_t *drc,uint32_t size)
{
	uint8_t ret=0;
	uint8_t i;
	for(i=0;i<size;i++)	{
		if(src[i]!=drc[i]){
			ret=1;
			return ret;
		}
	}
	return ret;
}


