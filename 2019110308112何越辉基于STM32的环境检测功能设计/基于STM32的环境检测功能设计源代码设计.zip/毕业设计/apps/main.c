#include "drv_systick.h"
#include "drv_usart.h"
#include "stdio.h"
#include "drv_exti.h"
#include "drv_dma.h"
#include "drv_adc.h"
#include "drv_oled.h"
#include "oled_gui.h"
#include "oled_apply.h"
#include "drv_led.h"
#include "drv_basetim.h"
#include "drv_oled_function.h"
#include "drv_dht11.h"
uint32_t SRC[20]={
			0x12111111,0x11121111,0x11111411,0x11111181,0x11111113,
			0x13111111,0x11131111,0x11111511,0x11111171,0x11111114,
			0x14111111,0x11141111,0x11111611,0x11111161,0x11111115,
			0x15111111,0x11151111,0x11111711,0x11111141,0x11111116
};
uint32_t DRC[20];
uint8_t led_flag=0;
uint8_t dma_flag=0;
uint8_t i;
extern u8 temperature;
extern u8 humidity;
int main(void)
{
	//��������
	SysTicks_Config(72);
	USART_Config();//���ڳ�ʼ��
	EXTI_Config();
	DMA1_Config(SRC,DRC,20);
	ADC1_Config();
	//LED��
	LED_Config();
	LED_CTL(LEDB|LEDG,OPEN);

	//TIM
	TIM7_Config();
	DHT11_Init();//��ʪ�ȳ�ʼ��
	OLED_Init_FunctionName();//��װOLED����
	OLED_symbol();//����
	SYSTICKs_DelayNms(5000);
	OLED_Login_now();
	SYSTICKs_DelayNms(5000);
	OLED_Login_successful();
	OLED_Init_FunctionName();//��װOLED����
	OLED_symbol();//����
	while(1)
		{
    //OLED_Continuous();
		//OLED���ܺ���
		SYSTICKs_DelayNms(1000);
		OLED_Function();
		SYSTICKs_DelayNms(500);	
	 }		
}
